# Задача: заменить всех маскотов на мальчика MyPal (файлы уже обработаны)

Файлы в mascot/ готовы: прозрачные, апскейл до 1400px, края очищены. НЕ обрабатывай и не вырезай заново.
- mypal-<pose>.webp (700px, для обычных экранов), mypal-<pose>@2x.webp (1400px, для retina), mypal-<pose>-master.png (исходник, положи в assets-src/mascot/, на сайт не отдавать).
- pose: wave, jump, tablet, point.
Скопируй webp в public/mascot/.

1. Компонент <Mascot pose size /> с srcset="/mascot/mypal-<pose>.webp 1x, /mascot/mypal-<pose>@2x.webp 2x", width/height заданы, decoding="async", lazy кроме первого экрана. Только он.
2. Найди ВСЕХ старых маскотов: grep -ri "bleep\|robot\|mascot\|antenna" src public и все inline <svg> с персонажем. Проверь каждый экран: Greeting, Parent Setup, Video, Mission, Complete, Hub, все игры, Ask MyPal (плитка и экран), модалки, ошибки, пустые состояния, favicon, og:image. Всё заменить на <Mascot>. Favicon сделай из головы wave (PNG 32/180/512).
3. Позы: wave для Greeting/Setup/приветствия; jump для успеха/Complete/побед; tablet для Video и ожидания; point для Mission, подсказок, Ask, ошибок.
4. Размеры: большой не выше 280px, маленький (плитка, шапка, пузырь речи) 48-72px. Не перекрывать кнопки на 390×844.
5. Ask MyPal: на плитке маленький маскот (point), на экране большой над "Hold to talk"; во время ответа tablet.
6. Покачивание 3 с (CSS), prefers-reduced-motion выключает.

Приёмка: grep -ri "bleep\|robot" src public пусто; ответом пришли список мест, где стоит <Mascot>, с экраном и позой; npm run build без ошибок; скриншоты всех экранов 390×844. Коммит без Co-Authored-By, без деплоя, жди "деплой".
