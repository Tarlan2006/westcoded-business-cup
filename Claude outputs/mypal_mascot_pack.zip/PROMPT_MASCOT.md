# Задача: заменить маскота на мальчика MyPal

Готовые файлы лежат в папке `mascot/` рядом с этим промптом (PNG, прозрачный фон, высота ~540px):
mypal-wave.png, mypal-jump.png, mypal-tablet.png, mypal-point.png.
Скопируй их в `public/mascot/`. Ничего не вырезай и не перегенерируй.

Мальчик с рюкзаком и есть MyPal, главный проводник по сайту. Старого робота/Bleep убрать полностью.

1. Один компонент `<Mascot pose="wave|jump|tablet|point" size />`, использовать только его. Сжать до WebP (≤60 KB на позу), width/height заданы, loading="lazy" кроме первого экрана.
2. Позы:
   - wave: Greeting, начало Parent Setup, приветствие в Hub
   - jump: Complete, правильный ответ, победа в играх
   - tablet: Video, ожидание, блок "Start here" в Hub
   - point: задания Mission, подсказки, "Try again", Ask MyPal
3. Заменить маскота везде: пузыри речи (сами пузыри оставить), иконки, плитки, шапка/логотип (голова из wave), favicon.
4. "Ask MyPal":
   - плитка на Hub: маленький маскот (point) вместо иконки робота.
   - экран Ask: большой маскот (point, во время ответа tablet) над "Hold to talk", ответ в пузыре рядом с ним.
5. Лёгкое покачивание 3 с (CSS), при prefers-reduced-motion выключено.
6. Приёмка: `grep -ri "bleep\|robot" src public` пусто; npm run build без ошибок; на 390×844 маскот не перекрывает кнопки. Коммит без Co-Authored-By, без деплоя, жди "деплой".
