# AIdos — исходный поиск перед изменениями

Исходная версия 4c59cf4. Файлы проекта, включая документацию, исходные макеты, сохранённые отчёты и метаданные. В таблице приведены также технические совпадения.

| Файл | Найденные выражения | Строки |
|---|---|---|
| AUDIT.md | $144, $18, locked, plans, plus, premium | 3, 52, 66, 69, 81, 95, 97, 98, 137, 141 |
| Claude outputs/CODEX_PROMPTS.md | unlock, плюс, тариф | 23, 36, 39, 52 |
| Claude outputs/DESIGN_BRIEF.md | paywall, тариф | 70, 99, 111 |
| Claude outputs/PLAN.md | unlock, плюс, тариф | 11, 18, 22, 103 |
| Claude outputs/PROMPT_AUDIT_FINAL.md | подписк, тариф | 65 |
| Claude outputs/PROMPT_FULL_RECONSTRUCTION.md | unlock | 37 |
| Claude outputs/PROMPT_LIGHT_REDESIGN.md | плюс | 4 |
| Claude outputs/PROMPT_PORT_DESIGNER_HTML.md | плюс | 43 |
| Claude outputs/PROMPT_SKETCH_GAME.md | плюс | 22 |
| Claude outputs/PROMPT_SKETCH_ISOLATED.md | плюс | 71 |
| design/screens/flow-verification.json | unlock | 16, 24 |
| docs/ARCHITECTURE.md | plus | 26 |
| docs/audit/after-ask-snapshot.json | locked | 1 |
| docs/audit/after-home.report.html | locked | 20 |
| docs/audit/after-home.report.json | locked | 434, 3712, 4745 |
| docs/audit/after-http-bundle.json | plans | 213 |
| docs/audit/after-hub-snapshot.json | locked | 1 |
| docs/audit/after-privacy.report.html | locked | 20 |
| docs/audit/after-privacy.report.json | locked | 430, 3461, 4390 |
| docs/audit/after-setup-snapshot.json | locked | 1 |
| docs/audit/after-sketch-reveal-snapshot.json | locked | 1 |
| docs/audit/after-video-snapshot.json | locked | 1 |
| docs/audit/before-home.report.html | locked | 20 |
| docs/audit/before-home.report.json | locked | 430, 3699, 4892 |
| docs/audit/before-privacy.report.html | locked | 20 |
| docs/audit/before-privacy.report.json | locked | 430, 3510, 4652 |
| docs/audit/knip-before.json | plus, premium | 742, 752 |
| docs/audit/seo-after-local.json | locked | 512 |
| docs/audit/seo-before.json | locked | 533 |
| docs/audit-2026-11-17/after-ask-snapshot.json | locked | 1 |
| docs/audit-2026-11-17/after-http-bundle.json | plans | 213 |
| docs/audit-2026-11-17/after-hub-snapshot.json | locked | 1 |
| docs/audit-2026-11-17/after-setup-snapshot.json | locked | 1 |
| docs/audit-2026-11-17/after-sketch-reveal-snapshot.json | locked | 1 |
| docs/audit-2026-11-17/after-video-snapshot.json | locked | 1 |
| docs/audit-2026-11-17/screens/smoke-report.json | plans, plus | 143, 147, 413, 417, 683, 687, 953, 957 |
| docs/audit-2026-11-17/screens-large/smoke-report.json | plans, plus | 143, 147 |
| docs/AUDIT-2026-11-17.md | locked, unlock | 33, 60 |
| docs/CODEX_PROMPTS.md | unlock, плюс, тариф | 23, 36, 39, 52 |
| docs/DEPLOY.md | plus | 49, 61 |
| docs/design/mission_control_prototype.html | unlock | 720, 1275, 1276, 1291 |
| docs/design-audit-2026-11-19/screens.csv | plans | 29 |
| docs/font-audit-elements.csv | plans | 431, 432, 433, 434, 435, 436, 437, 438, 439, 440, 441, 442, 443, 444, 445, 446, 447, 448, 449, 450, 451, 452, 453, 454, 455, 456, 457, 458, 1221, 1222, 1223, 1224, 1225, 1226, 1227, 1228, 1229, 1230, 1231, 1232, 1233, 1234, 1235, 1236, 1237, 1238, 1239, 1240, 1241, 1242, 1243, 1244, 1245, 1246, 1247, 1248 |
| docs/font-audit-live.md | тариф | 45, 78 |
| docs/mascot/emotions/report.md | подписк | 13 |
| docs/mascot/live-2026-11-19/observations.csv | plans | 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 277, 278, 279, 280, 281, 282, 283, 284, 285, 286, 287, 336, 337, 338, 339, 340, 341, 342, 343, 344, 345, 346, 347, 348, 349, 350, 351, 352, 353, 354, 355, 356, 357, 358, 359, 360, 361, 362, 363, 364, 365, 366, 367, 368, 369, 370, 371, 372, 373, 374, 375, 376, 377, 378 |
| docs/mascot/motion-report.md | подписк | 35 |
| docs/PLAN.md | unlock, плюс, тариф | 11, 18, 22, 103 |
| docs/releases/aidos-2026-11-17/local-smoke/smoke-report.json | plans, plus | 143, 147, 413, 417 |
| docs/releases/aidos-3d-audio-audit.md | locked | 21 |
| docs/releases/aidos-3d-evidence/after-http-bundle.json | plans | 213 |
| docs/releases/aidos-3d-evidence/large-text.json | plans, plus | 419, 434 |
| docs/releases/aidos-3d-evidence/production-smoke.json | plans, plus | 419, 434, 1118, 1133 |
| docs/releases/aidos-3d-evidence/smoke-report.json | plans, plus | 419, 434, 1118, 1133, 1817, 1832, 2533, 2548 |
| docs/releases/aidos-motion-2026-11-17.md | locked | 20 |
| docs/releases/aidos-motion-evidence/large-text.json | plans, plus | 390, 404 |
| docs/releases/aidos-motion-evidence/smoke-report.json | plans, plus | 390, 404, 1046, 1060, 1702, 1716, 2358, 2372 |
| docs/releases/unified-voice-evidence/smoke-report.json | plans, plus | 419, 434, 1118, 1133, 1817, 1832, 2533, 2548 |
| docs/releases/unified-voice.md | billing, plus | 13, 21, 26 |
| docs/screens/large-text/smoke-report.json | plans, plus | 143, 147 |
| docs/screens/smoke-report.json | plans, plus | 143, 147, 413, 417, 683, 687, 953, 957 |
| docs/site-kk.html | plans, plus, жазылым | 2 |
| docs/site-texts-kk.md | gameui.lockedseeplusplans, locked, monthly, plans, plus, premium, price, subscription, unlock, yearly, жазылым, плюс | 245, 264, 274, 275, 276, 314, 644, 645, 646, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657, 658, 659, 660, 661, 662, 663, 664, 665, 673, 674, 675, 676, 677, 678, 679, 1157 |
| docs/SUBMISSION_CHECKLIST.md | подписк | 23 |
| I18N_REPORT.md | plans, premium, тариф | 7, 80, 138 |
| package-lock.json | plus | 3462 |
| README.md | $144, $18, locked, plans, plus, premium, price, subscription | 17, 41 |
| scripts/ambience.check.mjs | unlock | 22, 27 |
| scripts/audio-latency.check.mjs | unlock | 23, 25, 58, 59 |
| scripts/i18n-e2e.mjs | plans, premium | 221 |
| scripts/mascot-lab.tsx | unlock | 6, 34 |
| scripts/smoke-prod.mjs | locked, plans, plus | 131, 132, 133, 134, 135, 137, 138, 142 |
| src/App.tsx | plans, plus, unlock | 6, 20, 43, 59, 131, 151, 235, 263, 278, 291, 312, 423, 431 |
| src/audio/engine.ts | unlock | 68 |
| src/audio/sfx.ts | unlock | 2, 13 |
| src/components/activitySuggestions.ts | unlock | 76 |
| src/components/Chains.tsx | plus | 2 |
| src/components/GameUI.tsx | gameui.lockedseeplusplans, locked, plans, plus | 30, 31, 35, 36 |
| src/components/Garage.tsx | locked | 21 |
| src/components/PrototypeFrame.tsx | unlock | 5, 32 |
| src/components/ToddlerPlayer.tsx | locked | 4, 21, 111, 120 |
| src/game/premium.ts | $144, $18, locked, monthly, plans, plus, premium, price, subscription, unlock, yearly | 2, 3, 6, 7, 8, 9, 11, 12, 14, 15, 16, 17, 18, 19, 20, 22, 23, 25, 26, 28, 29, 32, 33, 35 |
| src/games/balloons/check.ts | plus | 52 |
| src/games/sketch/README.md | plus | 51, 61 |
| src/games/space/README.md | plus | 15 |
| src/i18n/en.ts | gameui.lockedseeplusplans, locked, monthly, plans, plus, premium, price, subscription, unlock, yearly | 30, 77, 83, 147, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 396, 397, 398, 438, 439, 440, 441, 442, 443, 444 |
| src/i18n/kk.ts | gameui.lockedseeplusplans, locked, monthly, plans, plus, premium, price, subscription, unlock, yearly, жазылым, плюс | 32, 79, 85, 149, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 398, 399, 400, 440, 441, 442, 443, 444, 445, 446 |
| src/index.css | locked, plans, plus, price, yearly | 488, 489, 490, 491, 493, 494, 495, 496, 498, 499, 500, 502, 505, 506, 507, 508, 509, 511, 514, 518, 519 |
| src/screens/Ask.tsx | unlock | 7, 93, 144 |
| src/screens/Home.tsx | locked, plans, plus, premium, unlock | 10, 11, 44, 45, 80, 81, 82, 84, 86, 87 |
| src/screens/Plans.tsx | locked, plans, plus, premium, price, subscription, unlock, yearly | 5, 8, 9, 11, 13, 14, 17, 18, 19, 20, 24, 25, 28, 33, 34, 37, 38 |
| src/screens/Welcome.tsx | unlock | 4, 54 |
| src/state/useSessionTimer.ts | locked | 43 |

## Совпадения в названиях файлов

- design/screens/flow-preschool-locked-1280.png
- design/screens/flow-preschool-locked-390.png
- design/screens/flow-preschool-unlocked-1280.png
- design/screens/flow-preschool-unlocked-390.png
- design/screens/mypal-plans-390.png
- docs/audit-2026-11-17/screens-large/plans-390x844.png
- docs/audit-2026-11-17/screens/plans-1280x900.png
- docs/audit-2026-11-17/screens/plans-390x844.png
- docs/audit-2026-11-17/screens/plans-768x1024.png
- docs/audit-2026-11-17/screens/plans-844x390.png
- docs/releases/aidos-2026-11-17/local-smoke/plans-1280x900.png
- docs/releases/aidos-2026-11-17/local-smoke/plans-390x844.png
- docs/screens/en/plans-1280x800.png
- docs/screens/en/plans-390x844.png
- docs/screens/kk/plans-1280x800.png
- docs/screens/kk/plans-390x844.png
- docs/screens/large-text/plans-390x844.png
- docs/screens/plans-1280x900.png
- docs/screens/plans-390x844.png
- docs/screens/plans-768x1024.png
- docs/screens/plans-844x390.png
- src/game/premium.ts
- src/screens/Plans.tsx
